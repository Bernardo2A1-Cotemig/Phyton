# Painel de Controle de Tarefas (Flask)

Aplicação web em Flask com autenticação, CRUD de tarefas, banco SQLite,
integração com API externa, filtro por status, modo escuro e gráfico de
progresso com Chart.js.
