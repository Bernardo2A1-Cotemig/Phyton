import os
import sqlite3
from datetime import date
from functools import wraps

import requests
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tarefas.db")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")
app.config["DEBUG"] = os.environ.get("FLASK_DEBUG", "0") == "1"

STATUS_VALIDOS = ("pendente", "em_andamento", "concluida")

# Cache simples da frase motivacional diária (evita bater na API a cada requisição)
_advice_cache = {"data": None, "frase": None}


def get_db():
    """Abre (ou reaproveita) uma conexão SQLite para a requisição atual."""
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Cria as tabelas do banco caso não existam."""
    conn = sqlite3.connect(DATABASE)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT,
            status TEXT NOT NULL DEFAULT 'pendente',
            usuario_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
        """
    )
    conn.commit()
    conn.close()


def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def execute_db(query, args=()):
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    lastrowid = cur.lastrowid
    cur.close()
    return lastrowid


def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "usuario_id" not in session:
            flash("Você precisa estar logado para acessar essa página.", "warning")
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)

    return wrapped


@app.route("/")
def index():
    if "usuario_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")

        erros = []
        if not nome:
            erros.append("Informe o nome.")
        if not email or "@" not in email or "." not in email:
            erros.append("Informe um e-mail válido.")
        if len(senha) < 6:
            erros.append("A senha deve ter pelo menos 6 caracteres.")

        if not erros:
            existente = query_db("SELECT id FROM usuarios WHERE email = ?", (email,), one=True)
            if existente:
                erros.append("Já existe uma conta com este e-mail.")

        if erros:
            for erro in erros:
                flash(erro, "danger")
            return render_template("registro.html", nome=nome, email=email)

        senha_hash = generate_password_hash(senha)
        execute_db(
            "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
            (nome, email, senha_hash),
        )
        flash("Conta criada com sucesso! Faça login.", "success")
        return redirect(url_for("login"))

    return render_template("registro.html", nome="", email="")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")

        usuario = query_db("SELECT * FROM usuarios WHERE email = ?", (email,), one=True)
        if usuario and check_password_hash(usuario["senha"], senha):
            session.clear()
            session["usuario_id"] = usuario["id"]
            session["usuario_nome"] = usuario["nome"]
            return redirect(url_for("dashboard"))

        flash("E-mail ou senha inválidos.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("login"))



def get_frase_do_dia():
    hoje = date.today().isoformat()
    if _advice_cache["data"] == hoje and _advice_cache["frase"]:
        return _advice_cache["frase"]

    frase = "Continue firme, cada tarefa concluída é um passo à frente."
    try:
        resp = requests.get("https://api.adviceslip.com/advice", timeout=4)
        if resp.ok:
            frase = resp.json().get("slip", {}).get("advice", frase)
    except requests.RequestException:
        pass

    _advice_cache["data"] = hoje
    _advice_cache["frase"] = frase
    return frase


def tarefa_para_dict(row):
    return {
        "id": row["id"],
        "titulo": row["titulo"],
        "descricao": row["descricao"],
        "status": row["status"],
    }


@app.route("/dashboard")
@login_required
def dashboard():
    tarefas = query_db(
        "SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY id DESC",
        (session["usuario_id"],),
    )
    contagem = {"pendente": 0, "em_andamento": 0, "concluida": 0}
    for t in tarefas:
        if t["status"] in contagem:
            contagem[t["status"]] += 1

    return render_template(
        "dashboard.html",
        tarefas=tarefas,
        frase=get_frase_do_dia(),
        contagem=contagem,
    )


@app.route("/dashboard/tarefas")
@login_required
def dashboard_tarefas_json():
    """Retorna as tarefas do usuário em JSON, filtradas por status (usado pelo dropdown)."""
    status = request.args.get("status", "todas")
    if status in STATUS_VALIDOS:
        tarefas = query_db(
            "SELECT * FROM tarefas WHERE usuario_id = ? AND status = ? ORDER BY id DESC",
            (session["usuario_id"], status),
        )
    else:
        tarefas = query_db(
            "SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY id DESC",
            (session["usuario_id"],),
        )
    return jsonify([tarefa_para_dict(t) for t in tarefas])


@app.route("/dashboard/progresso")
@login_required
def dashboard_progresso_json():
    """Retorna a contagem de tarefas por status em JSON (usado pelo gráfico Chart.js)."""
    tarefas = query_db(
        "SELECT status, COUNT(*) as total FROM tarefas WHERE usuario_id = ? GROUP BY status",
        (session["usuario_id"],),
    )
    contagem = {"pendente": 0, "em_andamento": 0, "concluida": 0}
    for t in tarefas:
        if t["status"] in contagem:
            contagem[t["status"]] = t["total"]
    return jsonify(contagem)


@app.route("/nova_tarefa", methods=["GET", "POST"])
@login_required
def nova_tarefa():
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        descricao = request.form.get("descricao", "").strip()
        status = request.form.get("status", "pendente")

        erros = []
        if not titulo:
            erros.append("Informe o título da tarefa.")
        if status not in STATUS_VALIDOS:
            erros.append("Status inválido.")

        if erros:
            for erro in erros:
                flash(erro, "danger")
            return render_template(
                "form_tarefa.html",
                acao="Nova Tarefa",
                tarefa={"titulo": titulo, "descricao": descricao, "status": status},
            )

        execute_db(
            "INSERT INTO tarefas (titulo, descricao, status, usuario_id) VALUES (?, ?, ?, ?)",
            (titulo, descricao, status, session["usuario_id"]),
        )
        flash("Tarefa criada com sucesso.", "success")
        return redirect(url_for("dashboard"))

    return render_template(
        "form_tarefa.html",
        acao="Nova Tarefa",
        tarefa={"titulo": "", "descricao": "", "status": "pendente"},
    )


@app.route("/editar/<int:tarefa_id>", methods=["GET", "POST"])
@login_required
def editar_tarefa(tarefa_id):
    tarefa = query_db(
        "SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?",
        (tarefa_id, session["usuario_id"]),
        one=True,
    )
    if tarefa is None:
        flash("Tarefa não encontrada.", "danger")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        descricao = request.form.get("descricao", "").strip()
        status = request.form.get("status", "pendente")

        erros = []
        if not titulo:
            erros.append("Informe o título da tarefa.")
        if status not in STATUS_VALIDOS:
            erros.append("Status inválido.")

        if erros:
            for erro in erros:
                flash(erro, "danger")
            return render_template(
                "form_tarefa.html",
                acao="Editar Tarefa",
                tarefa={"id": tarefa_id, "titulo": titulo, "descricao": descricao, "status": status},
            )

        execute_db(
            "UPDATE tarefas SET titulo = ?, descricao = ?, status = ? WHERE id = ? AND usuario_id = ?",
            (titulo, descricao, status, tarefa_id, session["usuario_id"]),
        )
        flash("Tarefa atualizada com sucesso.", "success")
        return redirect(url_for("dashboard"))

    return render_template("form_tarefa.html", acao="Editar Tarefa", tarefa=tarefa)


@app.route("/excluir/<int:tarefa_id>", methods=["POST"])
@login_required
def excluir_tarefa(tarefa_id):
    execute_db(
        "DELETE FROM tarefas WHERE id = ? AND usuario_id = ?",
        (tarefa_id, session["usuario_id"]),
    )
    flash("Tarefa excluída.", "info")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    init_db()
    app.run(debug=app.config["DEBUG"])
else:
    init_db()
