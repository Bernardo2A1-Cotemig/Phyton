
(function () {
    const CHAVE = "painel-tarefas-modo-escuro";
    const botao = document.getElementById("btnModoEscuro");

    function aplicarModo(ativo) {
        document.body.classList.toggle("bg-dark", ativo);
        document.body.classList.toggle("text-light", ativo);
        document.body.classList.toggle("modo-escuro", ativo);
        if (botao) {
            botao.innerHTML = ativo
                ? '<i class="bi bi-sun"></i> Modo claro'
                : '<i class="bi bi-moon-stars"></i> Modo escuro';
        }
    }

    const salvo = localStorage.getItem(CHAVE) === "true";
    aplicarModo(salvo);

    if (botao) {
        botao.addEventListener("click", () => {
            const novoEstado = !document.body.classList.contains("modo-escuro");
            aplicarModo(novoEstado);
            localStorage.setItem(CHAVE, novoEstado);
        });
    }
})();
